/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package controller;

import DAOdatarental.datakendaraanDAO;
import DAOdatarental.datapengembalianDAO;
import DAOimplement.datakendaraanimplement;
import DAOimplement.datapengembalianimplement;
import java.util.List;
import javax.swing.JOptionPane;
import model.datakendaraan;
import model.datapeminjaman;
import model.datapengembalian;
import model.modeltabeldatapengembalian;
import view.frameAddKendaraan;
import view.framePengembalian;
import view.framePeminjaman;

public class datapengembaliancontroller {
    framePengembalian frame;
    datapengembalianimplement impldatakembali;
    datakendaraanimplement impldatakendaraan;
    List<datapengembalian> dp;
    
    public datapengembaliancontroller(framePengembalian frame) {
        this.frame = frame;
        impldatakembali = new datapengembalianDAO();
        impldatakendaraan = new datakendaraanDAO();
        dp = impldatakembali.getAll();
    }
    
    public void isitabel() {
        dp = impldatakembali.getAll();
        modeltabeldatapengembalian mp = new modeltabeldatapengembalian(dp);
        frame.getTabelPengembalian().setModel(mp);
    }
    
  
    
    public void deleteDataPengembalian(int kodePeminjaman) {
        datapeminjaman dp = new datapeminjaman();
            dp.setKode_peminjaman(kodePeminjaman);
        impldatakembali.delete(kodePeminjaman);
        JOptionPane.showMessageDialog(frame, "Berhasil mengembalikan kendaraan...");
    }
    
    
}

