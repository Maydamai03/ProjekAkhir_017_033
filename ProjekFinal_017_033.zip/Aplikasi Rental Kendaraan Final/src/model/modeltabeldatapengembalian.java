/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class modeltabeldatapengembalian extends AbstractTableModel {
    
    private List<datapengembalian> dp;

    public modeltabeldatapengembalian(List<datapengembalian> dp) {
        this.dp = dp;
    }

    @Override
    public int getRowCount() {
        return dp.size();
    }

    @Override
    public int getColumnCount() {
        return 8; // Adjust this according to the number of columns you have
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        datapengembalian dg = dp.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return dg.getKode_peminjaman();
            case 1:
                return dg.getNama_customer();
            case 2:
                return dg.getNik();
            case 3:
                return dg.getNo_telp();
            case 4:
                return dg.getLama_sewa();
            case 5:
                return dg.getTotal();
            case 6:
                return dg.getNama_kendaraan();
            case 7:
                return dg.getPlat();
             
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Kode Peminjaman";
            case 1:
                return "Nama Customer";
            case 2:
                return "NIK";
            case 3:
                return "No. Telp";
            case 4:
                return "Lama Sewa";
            case 5:
                return "Total";
            case 6:
                return "Nama Kendaraan";
            case 7:
                return "Plat Kendaraan";
            default:
                return null;
        }
    }
}



