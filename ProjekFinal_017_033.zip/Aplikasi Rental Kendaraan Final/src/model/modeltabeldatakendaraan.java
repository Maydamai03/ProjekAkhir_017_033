/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author ASUS
 */
public class modeltabeldatakendaraan extends AbstractTableModel{

    List<datakendaraan> dp;
    public modeltabeldatakendaraan(List<datakendaraan>dp){
        this.dp = dp;
    }
    
    @Override
    public int getRowCount() {
        return dp.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "ID-Kendaraan";
            case 1:
                return "Nama Kendaraan";
            case 2:
                return "Tipe";
            case 3:
                return "Plat Kendaraan";
            case 4:
                return "Harga Sewa";
            case 5:
                return "Status";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dp.get(row).getId_kendaraan();
            case 1:
                return dp.get(row).getNama_kendaraan();
            case 2:
                return dp.get(row).getTipe_kendaraan();
            case 3:
                return dp.get(row).getPlat_kendaraan();
            case 4:
                return dp.get(row).getHarga();
            case 5:
                return dp.get(row).getStatus();
            
            default:
                return null;
        }
    }
    
}
