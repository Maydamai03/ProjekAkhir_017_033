/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOdatarental;

import DAOimplement.datapengembalianimplement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.connector;
import model.datapengembalian;

/**
 *
 */
public class datapengembalianDAO implements datapengembalianimplement {

    Connection connection;

    final String select = "SELECT p.kode_peminjaman, p.nama_customer, p.nik, p.no_telp, p.lama_sewa, p.total, k.nama_kendaraan, k.plat "
                      + "FROM peminjaman p "
                      + "JOIN kendaraan k ON p.id_kendaraan = k.id_kendaraan";


//    final String updateStatus = "UPDATE kendaraan SET status='Tersedia' WHERE id_kendaraan=?";
    
    final String delete = "DELETE FROM peminjaman WHERE kode_peminjaman=?";

    public datapengembalianDAO() {
        connection = connector.connection();
    }

    @Override
    public void delete(int idKendaraan) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(delete);
            statement.setInt(1, idKendaraan);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<datapengembalian> getAll() {
        List<datapengembalian> dp = new ArrayList<>();
        try {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                datapengembalian dg = new datapengembalian();
                dg.setKode_peminjaman(rs.getInt("kode_peminjaman"));
                dg.setNama_customer(rs.getString("nama_customer"));
                dg.setNik(rs.getString("nik"));
                dg.setNo_telp(rs.getString("no_telp"));
                dg.setLama_sewa(rs.getInt("lama_sewa"));
                dg.setTotal(rs.getInt("total"));
                dg.setNama_kendaraan(rs.getString("nama_kendaraan"));
                dg.setPlat(rs.getString("plat"));

                dp.add(dg);
            }
        } catch (SQLException ex) {
            Logger.getLogger(datapengembalianDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dp;
    }

    @Override
    public void updateStatusTersedia(int id) {
//        PreparedStatement statement = null;
//        try {
//            statement = connection.prepareStatement(updateStatus);
//            statement.setInt(0, id);
//            statement.executeUpdate();
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        } finally {
//            try {
//                if (statement != null) {
//                    statement.close();
//                }
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//        }
//    }
}
}

