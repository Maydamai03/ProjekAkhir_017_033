/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

/**
 *
 * @author ASUS
 */
public class view {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        frameTampilData v = new frameTampilData();
//        v.setVisible(true);
//        v.setLocationRelativeTo(null);
//        
//        frameInputData v = new frameInputData();
//        v.setVisible(true);
//        v.setLocationRelativeTo(null);

        frameLogin v = new frameLogin();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
}
