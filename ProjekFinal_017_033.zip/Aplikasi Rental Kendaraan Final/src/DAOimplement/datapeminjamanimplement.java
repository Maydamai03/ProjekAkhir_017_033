/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOimplement;

import java.util.List;
import model.datakendaraan;
import model.datapeminjaman;

/**
 *
 * @author ACER
 */
public interface datapeminjamanimplement {
    public void insert(datapeminjaman p);
    public List<datakendaraan> getAll();
    public void updateStatusKendaraan(int idKendaraan, String status);
    public List<datakendaraan> search(String namaKendaraan);

    
    
}
